![logo.png](logo.png)

## 简介

一个基于 Web 的 V2ray 控制面板

![1.png](1.png)

![2.png](2.png)

## 系统支持

**请务必使用新系统，纯净的VPS系统安装!!!**

- Debian 8 
- **Debian 9(推荐)**
- Ubuntu 14
- Ubuntu 16
- CentOS 7

## 不支持
- CentOS 6

## 一键安装

目前处于测试阶段，不保证一键脚本能安装成功
> wget -N --no-check-certificate https://raw.githubusercontent.com/FunctionClub/V2ray.Fun/master/install.sh && bash install.sh

