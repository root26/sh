package xyz.sprov.blog.sprovui.exception;

public class V2rayConfigException extends RuntimeException {

    public V2rayConfigException() {}

    public V2rayConfigException(String msg) {
        super(msg);
    }

}
