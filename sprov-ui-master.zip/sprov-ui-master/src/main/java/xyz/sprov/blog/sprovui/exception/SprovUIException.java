package xyz.sprov.blog.sprovui.exception;

public class SprovUIException extends RuntimeException {

    public SprovUIException() {}

    public SprovUIException(String msg) {
        super(msg);
    }

}
