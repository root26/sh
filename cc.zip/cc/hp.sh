yum -y install python2
clear
echo "正在加载代理IP......"
wget http://s3128943610.test.upcdn.net/kail/ip.txt -O cc.txt >/dev/null 2>&1
sleep 2
echo "––––––––––––––––––––––––––––––––––––––––––––––––––"
echo "正在下载最新脚本......"
wget http://s3128943610.test.upcdn.net/kail/cc.py -O cc.py >/dev/null 2>&1
sleep 1
echo "––––––––––––––––––––––––––––––––––––––––––––––––––"
echo "正在加载最新脚本中......"
sleep 1
echo "––––––––––––––––––––––––––––––––––––––––––––––––––"
echo "© Powered by Fangaso"
sleep 1
clear
python2 cc.py